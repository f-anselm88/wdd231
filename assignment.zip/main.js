// ---------- Mobile nav toggle ----------
const navToggle = document.querySelector('.nav-toggle');
const primaryNav = document.querySelector('.primary-nav');

navToggle.addEventListener('click', () => {
  const isOpen = primaryNav.classList.toggle('is-open');
  navToggle.setAttribute('aria-expanded', isOpen);
});

// ---------- Footer: copyright year + last modified ----------
document.querySelector('#year').textContent = new Date().getFullYear();
document.querySelector('#lastModified').textContent = document.lastModified;

// ---------- Member directory ----------
const memberList = document.querySelector('#memberList');
const memberCount = document.querySelector('#memberCount');
const gridButton = document.querySelector('#gridView');
const listButton = document.querySelector('#listView');

const tierLabels = { 1: 'Member', 2: 'Silver Member', 3: 'Gold Member' };

async function getMembers() {
  try {
    const response = await fetch('data/members.json');
    if (!response.ok) {
      throw new Error(`Request failed: ${response.status}`);
    }
    const members = await response.json();
    displayMembers(members);
  } catch (error) {
    memberList.innerHTML = `<p role="alert">Member data could not be loaded right now. Please try again later.</p>`;
    console.error('Failed to load members.json:', error);
  }
}

function displayMembers(members) {
  memberCount.textContent = `${members.length} businesses`;

  memberList.innerHTML = members
    .map((member) => {
      const tierClass = `tier-${member.membership}`;
      const tierText = tierLabels[member.membership] ?? 'Member';

      return `
        <div class="member-card">
          <img src="images/${member.image}" alt="${member.name} logo" width="640" height="400" loading="lazy">
          <span class="member-tier ${tierClass}">${tierText}</span>
          <div class="member-body">
            <h3>${member.name}</h3>
            <p>${member.tagline}</p>
            <address>
              ${member.address}<br>
              ${member.phone}
            </address>
            <p class="member-links">
              <a href="${member.website}" target="_blank" rel="noopener">Website</a>
              <a href="tel:${member.phone.replace(/\s+/g, '')}">Call</a>
            </p>
          </div>
        </div>
      `;
    })
    .join('');
}

gridButton.addEventListener('click', () => {
  memberList.classList.remove('is-list');
  gridButton.setAttribute('aria-pressed', 'true');
  listButton.setAttribute('aria-pressed', 'false');
});

listButton.addEventListener('click', () => {
  memberList.classList.add('is-list');
  listButton.setAttribute('aria-pressed', 'true');
  gridButton.setAttribute('aria-pressed', 'false');
});

getMembers();
